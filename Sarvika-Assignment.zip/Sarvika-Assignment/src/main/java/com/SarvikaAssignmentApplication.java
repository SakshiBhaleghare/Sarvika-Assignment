package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SarvikaAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SarvikaAssignmentApplication.class, args);
	}

}
